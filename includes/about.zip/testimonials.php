<section id="testimonials" class="py-section bg-light" aria-labelledby="testimonials-heading">
    <div class="container">
        <div class="section-header section-header-center" data-aos="fade-up">
            <div class="section-label">Google Reviews</div>
            <h2 id="testimonials-heading" class="text-display-lg section-title">
                What Our <span class="gradient-text">Students Say</span>
            </h2>
            <p class="section-subtitle">Real reviews from real students on Google. See why thousands trust IUC Edu for their career transformation.</p>
        </div>

        <div class="google-reviews-summary" data-aos="fade-up">
            <div class="google-rating-big">
                <span class="rating-number">4.9</span>
                <div class="rating-stars">
                    <i class="bi bi-star-fill"></i>
                    <i class="bi bi-star-fill"></i>
                    <i class="bi bi-star-fill"></i>
                    <i class="bi bi-star-fill"></i>
                    <i class="bi bi-star-fill"></i>
                </div>
                <span class="rating-count">Based on 2,847 reviews</span>
            </div>
            <div class="google-badge">
                <svg class="google-logo" viewBox="0 0 24 24" width="24" height="24">
                    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                </svg>
                <span>Review</span>
            </div>
        </div>

        <div class="testimonial-scroll" style="overflow-x:auto;padding-bottom:0.5rem;scroll-snap-type:x mandatory;display:flex;gap:1.25rem;scrollbar-width:none">
            <?php foreach ($testimonials as $t): ?>
            <div class="testimonial-card google-review-card" style="min-width:340px;flex:1;scroll-snap-align:start" data-aos="fade-up">
                <div class="google-review-header">
                    <div class="google-reviewer-info">
                        <img src="<?= $t['avatar'] ?>" alt="<?= $t['name'] ?>" class="testimonial-avatar" loading="lazy" />
                        <div>
                            <div class="testimonial-name"><?= $t['name'] ?></div>
                            <div class="testimonial-role"><?= $t['role'] ?></div>
                        </div>
                    </div>
                    <div class="google-review-source">
                        <svg viewBox="0 0 24 24" width="16" height="16">
                            <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                            <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                            <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                            <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                        </svg>
                    </div>
                </div>
                <div class="testimonial-stars">
                    <?php for ($i = 0; $i < $t['rating']; $i++): ?>
                    <i class="bi bi-star-fill"></i>
                    <?php endfor; ?>
                    <span class="review-time">Batch <?= $t['batch'] ?></span>
                </div>
                <p class="testimonial-text">"<?= $t['quote'] ?>"</p>
                <div class="testimonial-footer">
                    <span class="badge badge-primary" style="margin-left:auto"><?= $t['salary'] ?></span>
                    <?php if ($t['verified']): ?>
                    <span class="verified-badge"><i class="bi bi-patch-check-fill"></i> Verified</span>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>