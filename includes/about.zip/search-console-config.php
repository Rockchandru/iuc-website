<?php
/* Local/private configuration. This file is intentionally excluded from Git. */
return [
    'property' => 'https://www.iucedu.com/',
    'credentials_file' => dirname(__DIR__) . '/admin/Google_Search_Console_service_account_JSON/iucedu-6baf125afec0.json',
    'cache_ttl' => 600,
    'row_limit' => 5000,
    'brand_terms' => ['iuc', 'iuc edu', 'iuc computers', 'iuc computer education'],
];
